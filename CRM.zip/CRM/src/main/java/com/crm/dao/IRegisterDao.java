package com.crm.dao;

import com.crm.model.CustomerBean;

public interface IRegisterDao {
	boolean  saveCustomer(CustomerBean  customerBean);

}
