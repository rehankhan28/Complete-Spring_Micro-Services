package com.oto.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.oto.entity.Passport;

public interface PassportRepository extends JpaRepository<Passport, Integer> {

}
