package com.oto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OneToOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
