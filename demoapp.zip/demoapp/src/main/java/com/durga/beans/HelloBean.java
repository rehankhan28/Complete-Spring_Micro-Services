package com.durga.beans;

import org.springframework.stereotype.Component;

@Component
public class HelloBean {
	public void sayHello()
	{
		System.out.println("Welcome To Spring Boot & Microservices...!!");
	}

}
