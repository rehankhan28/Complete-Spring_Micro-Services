package com.durga;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OptionandnonoptionappApplicationTests {

	@Test
	void contextLoads() {
	}

}
