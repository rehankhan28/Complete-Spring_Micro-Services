package com.pagination;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaginationappApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaginationappApplication.class, args);
	}

}
