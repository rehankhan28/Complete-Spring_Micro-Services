package com.durga.dao;

import java.util.List;

public interface ItestDao {
	void insertRecords();
	List selectRecords(); 

}
